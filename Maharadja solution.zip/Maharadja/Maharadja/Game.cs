﻿using System;
using System.Windows.Forms;

namespace Maharadja
{
    class Game
    {
        ListBox lbxStatus;
        public int[] goals = new int[] { 0, 0 };
        public int[] winsTosses = new int[] { 0, 0 };
        public int[] shotfails = new int[] { 0, 0 };
        public int[] ahotsuccesses = new int[] { 0, 0 };
        int possessIdx;
        int ballPosition;
        Random rndShoot;
        int shotsPerGame = 880;
        int[] ballPosses = new int[] { 0, 0 };

        int[,] players = new int[2, 11];
        int depth = 10;  // 11 - 1; 
        string trigram0, trigram1;

        public Game(ListBox albxStatus)
        {
            lbxStatus = albxStatus;
        }
        public void Play(FifaTeam aTeam1, FifaTeam aTeam2)
        {
            Initialize(aTeam1, aTeam2);
            BallToCenter();
            possessIdx = IdxWinToss();

            for (int shot = 0; shot <= shotsPerGame; shot++)
                EvaluateShot(Shoot());
        }

        Boolean Shoot()
        {
            /* Average team successrate increases/decrease by factor 2 with each 200 points Fifa ranking difference +/- */

            double diffRate;
            double failChance;

            if (possessIdx == 0)
                diffRate = (players[ballPosition, 0] - players[OtherBallPosition(), 1]) / 200;
            else
                diffRate = (players[OtherBallPosition(), 1] - players[ballPosition, 0]) / 200;

            failChance = Math.Pow(0.5, (Math.Abs(diffRate) + 1)); 
            if (diffRate < 0)
                failChance = 1 - failChance;

            new Random().Next();
            var rndshoot = rndShoot.NextDouble();
            return (rndshoot > failChance);

        }

        void ShootFail()
        {
            shotfails[possessIdx]++;
            BallToOtherTeam();
        }

        void ShootSucces()
        {
            ahotsuccesses[possessIdx]++;
            if (possessIdx == 0)
                ballPosition++;
            else
                ballPosition--;
        }

        int IdxWinToss()
        {
            int idx = rndShoot.Next(2);
            winsTosses[idx]++;
            return idx;
        }

        int OtherIdx()
        {
            return 1 - possessIdx;
        }
        int OtherBallPosition()
        {
            return depth - ballPosition;
        }

        void EvaluateShot(Boolean success)
        {
            if (success)
                ShootSucces();
            else
                ShootFail();

            ballPosses[possessIdx]++;

            if ((ballPosition < 0) || (ballPosition > depth))
            {
                goals[possessIdx]++;
                BallToOtherTeam();
                BallToCenter();
            }
        }

        void BallToCenter()
        {
            ballPosition = (depth) / 2;
        }

        void Initialize(FifaTeam aTeam0, FifaTeam aTeam1)
        {
            trigram0 = aTeam0.trigram;
            trigram1 = aTeam1.trigram;
            players = new int[aTeam1.players.Length, 2];
            for (var idx = 0; idx < aTeam1.players.Length; idx++)
            {
                players[idx, 0] = aTeam0.players[idx];
                players[idx, 1] = aTeam1.players[idx];
            }

            new Random().Next();
            rndShoot = new Random(Guid.NewGuid().GetHashCode());
            goals[0] = 0;
            goals[1] = 0;
            ballPosses[0] = 0;
            ballPosses[1] = 0;
            shotfails[0] = 0;
            shotfails[1] = 0;
            ahotsuccesses[0] = 0;
            ahotsuccesses[1] = 0;
        }

        void BallToOtherTeam()
        {
            possessIdx = Math.Abs(1 - possessIdx);
        }
        public void DisplayResults()
        {
            string result = "";
            string fmt = "* {0} wins! *   :";

            if (goals[0] == goals[1])
                result = "*     draw  *   :";
            else if (goals[0] > goals[1])
                result = String.Format(fmt, trigram0);
            else
                result = String.Format(fmt, trigram1);

            result = result + string.Format("  {0} - {1}:  {2} -{3}",
                trigram0.PadLeft(3), 
                trigram1.PadLeft(3),
                goals[0].ToString().PadLeft(2),
                goals[1].ToString().PadLeft(2)
                );

            lbxStatus.Items.Add(result);
        }


    }
}
