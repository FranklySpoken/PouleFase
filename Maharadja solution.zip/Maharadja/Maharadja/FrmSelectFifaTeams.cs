﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.IO;

namespace Maharadja
{
    public partial class FrmSelectFifaTeams : Form
    {
        IList<FifaTeam> teams { get; set; }

        public FifaTeam[] teamsSelected = new FifaTeam [4];

        public FrmSelectFifaTeams()
        {
            InitializeComponent();
            Initialize();
        }
        void Initialize()
        {
            string fifaTeamsFileName = AppDomain.CurrentDomain.BaseDirectory + "\\data\\FifaTeams.csv";
            if (File.Exists(fifaTeamsFileName))
            {


                teams = File.ReadAllLines(fifaTeamsFileName)
                                   .Select(v => FifaTeam.FromCsv(v))
                                   .ToList();

                dgvTeams.DataSource = teams;
                dgvTeams.Columns[0].DataPropertyName = "name";
                dgvTeams.Columns[1].DataPropertyName = "rank";
                dgvTeams.Columns[2].DataPropertyName = "trigram";
            }
            else
            {
                MessageBox.Show("File " + fifaTeamsFileName + " does not exist", "File not found", MessageBoxButtons.OK);
                Close();
            }


        }

        private void dgvTeams_SelectionChanged(object sender, EventArgs e)  
        {
            string txt = dgvTeams.SelectedRows.Count.ToString();
            btnSelect.Enabled = ( dgvTeams.SelectedRows.Count == 4 );
            btnAccept.Enabled = false;
            if (dgvTeams.SelectedRows.Count == 1)
                lblSelect.Text = dgvTeams.SelectedRows.Count.ToString() + " team ready for selection";
            else
                lblSelect.Text = dgvTeams.SelectedRows.Count.ToString() + " teams ready for selection";
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {

            lblSelect.Text = dgvTeams.SelectedRows[3].Cells[2].Value.ToString() + " " +
                             dgvTeams.SelectedRows[2].Cells[2].Value.ToString() + " " +
                             dgvTeams.SelectedRows[1].Cells[2].Value.ToString() + " " +
                             dgvTeams.SelectedRows[0].Cells[2].Value.ToString() + " selected";

            btnAccept.Enabled = true;
        }

        private void dgvTeams_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            dgvTeams.ClearSelection();
        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            for (var idx = 0; idx < 4; idx++)
            {
                teamsSelected[idx] = teams[dgvTeams.SelectedRows[idx].Index];
                teamsSelected[idx].id = idx;
            }
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
