﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using System.IO;

namespace Maharadja
{
    public class FifaTeam
    {
        public int[] players = new int[11];
        public int id;
        public string name { get; set; }
        public int rank { get; set; }
        public string trigram { get; set; }

        public FifaTeam(int aid, string aname, int arank, string atrigram)
        {
            id = aid;
            name = aname;
            rank = arank;
            trigram = atrigram;
            new Random().Next();
            var rnd = new Random(Guid.NewGuid().GetHashCode());
            int topStrengthSupplement = 200;
            int StrengthDecrease = topStrengthSupplement * 2/ 11;
            int averagePlayerStrength = arank / 11;
            int playerStrength = averagePlayerStrength + topStrengthSupplement; // keepers has best success rate, attackers the least

            for (var idx = 0; idx < 11; idx++)
            {
                players[idx] = rnd.Next(playerStrength-30, playerStrength+30);
                playerStrength = playerStrength - StrengthDecrease;
            }
        }
        public static FifaTeam FromCsv(string csvLine)
        {
            string[] values = csvLine.Split(';');
            if (values.Count() >= 3)
            {
                FifaTeam fifaTeam = new FifaTeam(-1, values[0].Trim(), Convert.ToInt32(values[1]), values[2].Trim());
                return fifaTeam;
            }
            else
                return null;
        }
    }
}
