﻿
namespace Maharadja
{
    using System;
    using System.Collections.Generic;
    // Simple business object. A PartId is used to identify the type of part 
    // but the part name can change. 
    public class Rank : IEquatable<Rank>, IComparable<Rank>
    {
        public string teamTrigram { get; set; }
        public int teamId { get; set; }
        public int teamPoints { get; set; }
        public int teamGoalsPlus { get; set; }
        public int teamGoalsMinus { get; set; }
        public int[,] gamelist;

        public override string ToString()
        {
            return "ID: " + teamId + "   Name: " + teamTrigram;
        }
        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            Rank objAsRank = obj as Rank;
            if (objAsRank == null) return false;
            else return Equals(objAsRank);
        }
        public int SortByNameAscending(string name1, string name2)
        {

            return name1.CompareTo(name2);
        }

        // Default comparer for Part type.
        public int CompareTo(Rank compareRank)
        {
            /* FIFA ranking
            The ranking of each team in each group shall be determined as follows:
            a) greatest number of points obtained in all group matches;
            b) goal difference in all group matches;
            c) greatest number of goals scored in all group matches.

            If two or more teams are equal on the basis of the above three criteria, their rankings shall be determined as follows:
            d) (Void in this case) greatest number of points obtained in the group matches between the teams concerned;
            e) goal difference resulting from the group matches between the teams concerned;
            f) (Void in this case) greater number of goals scored in all group matches between the teams concerned;
            g) drawing of lots by the FIFA Organising Committee.
                */
            // A null value means that this object is greater.
            if (compareRank == null)
                return 1;
            else
            {
                int result;

                result = compareRank.teamPoints - teamPoints;
                if (result == 0)
                    result = (compareRank.teamGoalsPlus - compareRank.teamGoalsMinus) - (teamGoalsPlus - teamGoalsMinus);
                if (result == 0)
                    result = compareRank.teamGoalsPlus - teamGoalsPlus;
                if (result == 0)
                    result = RankGame(teamId, compareRank.teamId);

                if (result == 0)
                {
                    result = (new Random().Next(2) == 1) ? 1 : -1;
                }

                return result;
            }
            
        }

        int RankGame(int teamId, int compareTeamId)
        {
            int gameIdx = FindGame(teamId, compareTeamId);
            int diffgoals = gamelist[gameIdx, 3] - gamelist[gameIdx, 2];

            return (gamelist[gameIdx, 0] == teamId) ? diffgoals : -diffgoals;
        }
        int FindGame(int teamId, int compareTeamId)
        {
            int gameIdx = 0;
            bool found = false;

            while (!found && gameIdx < 6)
            {
                found = ((gamelist[gameIdx, 0] == teamId) || (gamelist[gameIdx, 1] == teamId)) &&
                        ((gamelist[gameIdx, 0] == compareTeamId) || (gamelist[gameIdx, 1] == compareTeamId));
                if (!found)
                    gameIdx++;
            }
            return gameIdx;
        }

        public override int GetHashCode()
        {
            return teamId;
        }
        public bool Equals(Rank other)
        {
            if (other == null) return false;
            return (this.teamId.Equals(other.teamId));
        }

    }
}
