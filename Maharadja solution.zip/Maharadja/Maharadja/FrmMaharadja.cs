﻿using System;
using System.Windows.Forms;

namespace Maharadja
{
    public partial class FrmMaharadja : Form
    {
        FifaTeam[] teamsSelected = new FifaTeam[4];

        public FrmMaharadja()
        {
          InitializeComponent();
        }

        private void btnLetsPlay_Click(object sender, EventArgs e)
        {
          lbxStatus.Items.Clear();
          new Random().Next();

          FifaTeam[] teams = new FifaTeam[] { teamsSelected[0], teamsSelected[1], teamsSelected[2], teamsSelected[3], }; 
          var poule = new Poule(teams, lbxStatus);

          poule.Play();
          poule.DisplayResults();
        }

        private void btnSelectTeams_Click(object sender, EventArgs e)
        {
            btnLetsPlay.Enabled = false;
            using (var form = new FrmSelectFifaTeams())
            {
                form.Owner = this;
                form.StartPosition = FormStartPosition.CenterParent;
                var result = form.ShowDialog(this);
                if (result == DialogResult.OK)
                {
                    btnLetsPlay.Enabled = true;
                    for (var idx = 0; idx < 4; idx++)
                        teamsSelected[idx] = form.teamsSelected[idx]; 
                }
            }
        }
    }
}
