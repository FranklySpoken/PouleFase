﻿namespace Maharadja
{
    partial class FrmMaharadja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLetsPlay = new System.Windows.Forms.Button();
            this.lblResult = new System.Windows.Forms.Label();
            this.lbxStatus = new System.Windows.Forms.ListBox();
            this.btnSelectTeams = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLetsPlay
            // 
            this.btnLetsPlay.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLetsPlay.AutoSize = true;
            this.btnLetsPlay.Enabled = false;
            this.btnLetsPlay.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetsPlay.Location = new System.Drawing.Point(169, 0);
            this.btnLetsPlay.Name = "btnLetsPlay";
            this.btnLetsPlay.Size = new System.Drawing.Size(140, 32);
            this.btnLetsPlay.TabIndex = 1;
            this.btnLetsPlay.Text = "* Let\'s Play *";
            this.btnLetsPlay.UseVisualStyleBackColor = true;
            this.btnLetsPlay.Click += new System.EventHandler(this.btnLetsPlay_Click);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(40, 82);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(0, 13);
            this.lblResult.TabIndex = 2;
            // 
            // lbxStatus
            // 
            this.lbxStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbxStatus.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxStatus.FormattingEnabled = true;
            this.lbxStatus.ItemHeight = 14;
            this.lbxStatus.Location = new System.Drawing.Point(12, 39);
            this.lbxStatus.Name = "lbxStatus";
            this.lbxStatus.Size = new System.Drawing.Size(298, 284);
            this.lbxStatus.TabIndex = 3;
            // 
            // btnSelectTeams
            // 
            this.btnSelectTeams.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSelectTeams.AutoSize = true;
            this.btnSelectTeams.Location = new System.Drawing.Point(12, 0);
            this.btnSelectTeams.Name = "btnSelectTeams";
            this.btnSelectTeams.Size = new System.Drawing.Size(140, 32);
            this.btnSelectTeams.TabIndex = 4;
            this.btnSelectTeams.Text = "Select Fifa Teams";
            this.btnSelectTeams.UseVisualStyleBackColor = true;
            this.btnSelectTeams.Click += new System.EventHandler(this.btnSelectTeams_Click);
            // 
            // FrmMaharadja
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(324, 341);
            this.Controls.Add(this.btnSelectTeams);
            this.Controls.Add(this.lbxStatus);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.btnLetsPlay);
            this.Name = "FrmMaharadja";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Maharadja";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLetsPlay;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.ListBox lbxStatus;
        private System.Windows.Forms.Button btnSelectTeams;
    }
}

