﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Maharadja
{
    class Poule
    {
        FifaTeam[] teams     = new FifaTeam[4];
        int[] wins       = new int[4] { 0, 0, 0, 0 };
        int[] losses     = new int[4] { 0, 0, 0, 0 };
        int[] draws      = new int[4] { 0, 0, 0, 0 };
        int[] points     = new int[4] { 0, 0, 0, 0 };
        int[] goalsPlus  = new int[4] { 0, 0, 0, 0 };
        int[] goalsMinus = new int[4] { 0, 0, 0, 0 };
        List<Rank> ranks = new List<Rank>();

        ListBox lbxStatus;
        int[,] gamelist = new int[,]
        {
            { 0, 1, 0, 0 },
            { 2, 3, 0, 0 },
            { 3, 0, 0, 0 },
            { 1, 2, 0, 0 },
            { 0, 2, 0, 0 },
            { 1, 3, 0, 0 },
        };

        void Initialize()
        {
            for (var idx = 0; idx < 4; idx++)
            {
                wins[idx] = 0;
                losses[idx] = 0;
                draws[idx] = 0;
                points[idx] = 0;
                goalsPlus[idx] = 0;
                goalsMinus[idx] = 0;
            }
        }
        public Poule(FifaTeam[] ateams, ListBox albxStatus)
        {
            lbxStatus = albxStatus;
            for (var idx = 0; idx < 4; idx++)
                teams[idx] = ateams[idx];

            Initialize();
        }
        public void DoRank()
        {
            // Add parts to the list.
            for (var idx = 0; idx < 4; idx++)
                ranks.Add(new Rank()
                {
                    teamTrigram = teams[idx].trigram,
                    teamId = teams[idx].id,
                    teamPoints = points[idx],
                    teamGoalsPlus = goalsPlus[idx],
                    teamGoalsMinus = goalsMinus[idx],
                    gamelist = gamelist
                });
            ranks.Sort(); 

        }
        
        public void DisplayResults()
        {
            DoRank();
            lbxStatus.Items.Add("");
            lbxStatus.Items.Add("Team   W   L   D   P   +   - ");
            int ridx;

            for (var idx = 0; idx < 4; idx++)
            {
              ridx = ranks[idx].teamId;
                lbxStatus.Items.Add(String.Format(" {0} {1} {2} {3} {4} {5} {6} ",
                    teams[ridx].trigram.PadLeft(3), 
                    wins[ridx].ToString().PadLeft(3), 
                    losses[ridx].ToString().PadLeft(3), 
                    draws[ridx].ToString().PadLeft(3), 
                    points[ridx].ToString().PadLeft(3), 
                    goalsPlus[ridx].ToString().PadLeft(3), 
                    goalsMinus[ridx].ToString().PadLeft(3)));
            }
            lbxStatus.Items.Add("");
            lbxStatus.Items.Add(String.Format(" {0} and {1} will go to the next round",
                ranks[0].teamTrigram, ranks[1].teamTrigram));
        }

        public void Play()
        {
            var game = new Game(lbxStatus);
            int idx0;
            int idx1;

            Initialize();
            for (var idx = 0; idx < 6; idx++)
            {
                idx0 = gamelist[idx, 0];
                idx1 = gamelist[idx, 1];
                game.Play(teams[idx0], teams[idx1]);
                game.DisplayResults();

                goalsPlus[idx0] = goalsPlus[idx0] + game.goals[0];
                goalsPlus[idx1] = goalsPlus[idx1] + game.goals[1];
                goalsMinus[idx0] = goalsMinus[idx0] + game.goals[1];
                goalsMinus[idx1] = goalsMinus[idx1] + game.goals[0];
                gamelist[idx, 2] = game.goals[0];
                gamelist[idx, 3] = game.goals[1];

                if (game.goals[0] > game.goals[1])
                {
                    points[idx0] = points[idx0] + 3;
                    wins[idx0]++;
                    losses[idx1]++;
                }
                else if (game.goals[1] > game.goals[0])
                {
                    points[idx1] = points[idx1] + 3;
                    wins[idx1]++;
                    losses[idx0]++;
                }
                else
                {
                    points[idx0]++;
                    points[idx1]++;
                    draws[idx0]++;
                    draws[idx1]++;
                }
            }
        }
    }
}
